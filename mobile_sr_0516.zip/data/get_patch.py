import cv2
from PIL import Image
import os
from multiprocessing import Pool



def to_cv_array(x):
    """
    Convert torch.Tensor / PIL.Image to opencv numpy.array
    :param x: tensor / PIL.Image
    :return: 3D numpy.array
    """
    if isinstance(x, Image.Image):
        return cv2.cvtColor(np.array(x), cv2.COLOR_RGB2BGR)
    elif torch.is_tensor(x):
        x = x.squeeze(0) if len(x.shape) == 4 else x
        x = np.transpose(x.numpy() * 255., (1, 2, 0))
        return cv2.cvtColor(x.astype(np.uint8), cv2.COLOR_RGB2BGR)

def save_patch(patch,var_thresh,select_folder,patch_name,patch_folder):
    if is_hr:
        patch_cv = to_cv_array(patch)
        im_gray = cv2.cvtColor(patch_cv, cv2.COLOR_BGR2GRAY)
        im_var = cv2.Laplacian(im_gray, cv2.CV_64F).var()
        if im_var < var_thresh:
            patch.save(os.path.join(select_folder, patch_name))
            print('saving: %s' % os.path.join(select_folder, patch_name))
        else:
            patch.save(os.path.join(patch_folder, patch_name))
            print('saving: %s' % os.path.join(patch_folder, patch_name))
    else:
        patch.save(os.path.join(patch_folder, patch_name))
        print('saving: %s' % os.path.join(patch_folder, patch_name))

def _all_images(path):
    """
    return all images in the folder
    :param path: path to Data Folder, absolute path
    :return: 1D list of image files absolute path
    """
    # TODO: Tail Call Elimination
    abs_path = os.path.abspath(path)
    image_files = list()
    for subpath in os.listdir(abs_path):
        if os.path.isdir(os.path.join(abs_path, subpath)):
            image_files = image_files + _all_images(os.path.join(abs_path, subpath))
        else:
            if _is_image_file(subpath):
                image_files.append(os.path.join(abs_path, subpath))
    image_files.sort()
    return image_files

def stride_crop_img(im_name):

    ## Image, Patch Size, Stride Preparation Based on HR/LR
    var_thresh = 20
    im = Image.open(im_name)
    im_name = os.path.basename(im_name).split('.')[0]
    w, h = im.size
    scale = set_scale if is_hr else 1
    # 裁剪掉边缘 1×scale 一圈
    im = im.crop((1 * scale, 1 * scale, w - 1 * scale, h - 1 * scale))
    w, h = im.size

    # 根据LR的patch size和stride，计算放大后的相应参数
    patch_size = scale * lr_patch_size
    stride = scale * lr_stride
    if is_hr:
        patch_folder = os.path.join(dst_folder, 'HR_patch')
        select_folder = os.path.join(dst_folder, 'val_HR')
    else:
        patch_folder = os.path.join(dst_folder, 'LR_patch')
        select_folder = os.path.join(dst_folder, 'val_LR')

    cnt = 0
    #剩余边的大小
    x_last = w-(((w - patch_size) // stride) * stride + patch_size)
    y_last = h-(((h - patch_size) // stride) * stride + patch_size)
    # 剩余部分大于patch_size的1/2就从后往前多切一次
    x_flag = False
    y_flag = False
    if x_last > (patch_size/2):
        x_flag = True
    if y_last > (patch_size/2):
        y_flag = True

    a= (w - patch_size) // stride + 1
    b= (h - patch_size) // stride + 1
    for x in range((w - patch_size) // stride + 1):
        for y in range((h - patch_size) // stride + 1):
            startx = x * stride
            starty = y * stride
            patch = im.crop([startx, starty, startx + patch_size, starty + patch_size])
            patch_name = '%s_%d.png' % (im_name, cnt)
            cnt += 1
            save_patch(patch, var_thresh, select_folder, patch_name, patch_folder)

    if x_flag:
        if y_flag:
            for x in range((w - patch_size) // stride + 1):
                startx = x * stride
                patch = im.crop([startx, h-patch_size, startx + patch_size, h])
                patch_name = '%s_%d.png' % (im_name, cnt)
                cnt += 1
                save_patch(patch, var_thresh, select_folder, patch_name, patch_folder)
            for y in range((h - patch_size) // stride + 1):
                starty = y * stride
                patch = im.crop([w-patch_size, starty, w, starty + patch_size])
                patch_name = '%s_%d.png' % (im_name, cnt)
                cnt += 1
                save_patch(patch, var_thresh, select_folder, patch_name, patch_folder)
            patch = im.crop([w-patch_size, h-patch_size, w, h])
            patch_name = '%s_%d.png' % (im_name, cnt)
            cnt += 1
            save_patch(patch, var_thresh, select_folder, patch_name, patch_folder)
        else:
            for y in range((h - patch_size) // stride + 1):
                starty = y * stride
                patch = im.crop([w-patch_size, starty, w, starty + patch_size])
                patch_name = '%s_%d.png' % (im_name, cnt)
                cnt += 1
                save_patch(patch, var_thresh, select_folder, patch_name, patch_folder)
    else:
        if y_flag:
            for x in range((w - patch_size) // stride + 1):
                startx = x * stride
                patch = im.crop([startx, h-patch_size, startx + patch_size, h])
                patch_name = '%s_%d.png' % (im_name, cnt)
                cnt += 1
                save_patch(patch, var_thresh, select_folder, patch_name, patch_folder)





if __name__ == '__main__':

    global dst_folder
    global lr_patch_size
    global lr_stride
    lr_patch_size = 256
    lr_stride = 150
    set_scale = 3


    dst_folder = '/media/data1/DRealSR/DRealSR4/val/x3'
    hr_dir = '/media/data1/DRealSR/DRealSR4/x3/image_test'
    lr_dir = '/media/data1/DRealSR/DRealSR4/x3/image_LR'

    global is_hr

    def makedir(path):
        path = os.path.join(dst_folder, path)
        if not os.path.exists(path):
            os.makedirs(path)
    makedir('HR_patch')
    makedir('LR_patch')
    makedir('val_HR')   # 根据方差筛选出的HR patch
    makedir('val_LR')   # LR patch先不筛选，人工再次筛选HR Patch后，

    print('Cropping HR Images...')
    hr_names = _all_images(hr_dir)
    is_hr = True
    pool = Pool()
    pool.map(stride_crop_img, hr_names)
    pool.close()
    pool.join()
    print('Cropping LR Images...')
    # lr_names = _all_images(lr_dir)
    is_hr = False
    pool = Pool()
    pool.map(stride_crop_img, lr_names)
    pool.close()
    pool.join()
